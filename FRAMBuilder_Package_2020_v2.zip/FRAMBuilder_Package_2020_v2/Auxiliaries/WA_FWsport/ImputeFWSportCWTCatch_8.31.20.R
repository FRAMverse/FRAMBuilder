#######################################################################################
############ CODE TO ESTIMATE FW SPORT RECOVERIES FROM CATCH AND ESCAPEMENT############
#######################################################################################

# Clear workspace
rm(list=ls(all=TRUE))

# Load required libraries
library(doBy)
library(readxl)

#######################################################################################
# Set the paths to the MSF_Impacts and MSP databases for Baseline_RetRel function
paths = list("C:\\Users\\jonathan.carey\\Documents\\FRAM\\Calibration_Validation\\Chinook\\2020\\FRAMBuilder\\Auxiliaries\\WA_FWsport\\FWSportEsts_8.31.20.xlsx",
             "C:\\Users\\jonathan.carey\\Documents\\FRAM\\Calibration_Validation\\Chinook\\2020\\FRAMBuilder\\Auxiliaries\\WA_FWsport\\")
#######################################################################################

# Set the output file path
outfile = paths[[2]]

# Read in source data
catch_esc <- read_excel(paths[[1]], "CatchEsc")
tags <- read_excel(paths[[1]], sheet = "Tags", range = "A1:D133")
key <- read_excel(paths[[1]], "Key")
rec <- read_excel(paths[[1]], "Recoveries")
rel <- read_excel(paths[[1]], "Releases")
WB_Mar_Spt <- read_excel(paths[[1]], sheet = "WB MarSport", range = "L1:AF27")

##########################
# PREPARE CWT RECOVERIES #
##########################

# filter out strays from recoveries
rec <- rec[rec$stray == 0, ]

# merge tags and recoveries
tags <- merge(tags[tags$include == 1, ],key)
rec <- merge(tags,rec,by = "tag_code")

# add age field
rec$age <- rec$run_year - rec$brood_year.x

# sum estimated recoveries by river, tag code, age, and escapement type
rec <- summaryBy(estimated_number~fishery.x+tag_code+age+fishery.y, data=rec, FUN=sum)

# translate RMIS fishery code into escapement type
i=1
for(i in 1:dim(rec)[1]) {
    if(rec$fishery.y[i] == 46) {
        rec$esc_type[i] <- "FW Sport"
    }
    if(rec$fishery.y[i] == 50) {
        rec$esc_type[i] <- "Hatchery"
    }
    if(rec$fishery.y[i] == 54) {
        rec$esc_type[i] <- "Spawning Ground"
    }
}
rec <- rec[ ,c(1:3,6,5)]
# reshape to put hatchery and spawning ground esc types into their own columns
rec <- reshape(rec,timevar = "esc_type",idvar = c("fishery.x","tag_code","age"),
               direction = "wide")
# rename columns
colnames(rec)[4] <- "CWT_esc_hatch"
colnames(rec)[5] <- "CWT_fw_sport"
colnames(rec)[6] <- "CWT_esc_sg"
# replace NAs with 0
rec$CWT_esc_hatch[is.na(rec$CWT_esc_hatch)] <- 0
rec$CWT_esc_sg[is.na(rec$CWT_esc_sg)] <- 0
rec$CWT_fw_sport[is.na(rec$CWT_fw_sport)] <- 0

#######################
# PREP CATCH_ESC DATA #
#######################

# merge tags and catch_esc data frames, add age field
catch_esc <- merge(tags,catch_esc)
catch_esc$age <- catch_esc$run_year - catch_esc$brood_year

################################################################
# Merge CWT recovery data with total fishery & escapement data #
################################################################

dat <- merge(catch_esc,rec,all.y=TRUE)
dat <- dat[complete.cases(dat), ]
dat <- dat[ ,c(1:22,24:26)]
dat <- dat[order(dat$fishery,dat$abbrev,dat$tag_code,dat$brood_year,dat$run_year), ]

# filter to age 3+
dat <- dat[dat$age > 2, ]

unique(dat$age)

#########################################################
# Compute estimated FW sport CWT recoveries by tag code #
#########################################################

# For NS;  FW sport catch by age/tag code = Hatchery + SpawnGround escapement of tag 
#          code / Hatchery + SpawnGround total escapement * FW fishery catch
# For MSF; FW sport catch by tag code = Hatchery escapement of tag code / 
#          Marked Hatchery Escapement * Marked FW fishery catch
i=1
for(i in 1:dim(dat)[1]) {
    # impute if necessary
    if(dat$impute_ind[i] == 1) {
        if(dat$msf_ind[i] == 0) {
            esc_tot <- dat$esc_rack[i] + dat$esc_wild[i] # include offsite here??
            esc_CWT <- dat$CWT_esc_hatch[i] + dat$CWT_esc_sg[i]
            dat$CWT_fw_sport[i] <- esc_CWT / esc_tot * dat$fish_catch[i]
        }
        if(dat$msf_ind[i] == 1) {
            esc_rackAD <- dat$esc_rack[i] * as.numeric(as.character(dat$hatch_MR[i]))
            dat$CWT_fw_sport[i] <- dat$CWT_esc_hatch[i] / esc_rackAD * dat$fish_catch[i]
        }
    }
}

# # Filter out records that were not imputed (as they're already in CAS and we don't want to duplicate them)
# dat <- dat[dat$impute_ind == 1, ]

# Reformat for easy loading into CAS
dat$fish_open <- format(as.Date(dat$fish_open, origin = "1899-12-30"), format="%Y%m%d")
Output <- dat[ ,c(5,15,5,5,5,5,5,5,1,5,5,8,5,24,5,13,5,5,5,5,11)]
names <- c("RecoveryId","RecoveryDate","SamplingPeriodType","SamplingPeriodNumber","Species",
           "Sex","Length","LengthCode","TagCode","TagStatus","EstimationLevel",
           "RecoverySite","CWDBFishery","EstimatedNumber","SampleType",
           "RunYear","RecordedMark","CatchSampleId","DetectionMethod",
           "Agency","Fishery")
colnames(Output) <- names

# Remove records with est_# == 0 (because if these get loaded in, CAS will assign adj_est_# of 1)
Output <- Output[!(Output$EstimatedNumber == 0), ]

# Format externally calculated Willapa Marine Sport recoveries for appending
WB_Mar_Spt <- WB_Mar_Spt[WB_Mar_Spt$impute_ind == 1 ,c(10,11,10,10,10,10,10,10,1,10,10,20,10,19,10,9,10,10,10,10,21)]
colnames(WB_Mar_Spt) <- names
WB_Mar_Spt$RecoveryDate <- format(as.Date(WB_Mar_Spt$RecoveryDate, origin = "1899-12-30"), format="%Y%m%d")

# Append Willapa marine sport recoveries to Output
Output <- rbind(Output,WB_Mar_Spt)


prefix <- "FWspt_"

i=1
for(i in 1:dim(Output)[1]) {
    # Output$imputed[i] <- ifelse(Output$imputed[i] == 1, "yes", "no")
    Output$RecoveryId[i] <- paste(prefix,sprintf("%04d",i),sep="")
    Output$SamplingPeriodType[i] <- 1
    Output$SamplingPeriodNumber[i] <- 1
    Output$Species[i] <- 1
    Output$Sex[i] <- ""
    Output$Length[i] <- ""
    Output$LengthCode[i] <- ""
    Output$TagStatus[i] <- 1
    Output$EstimationLevel[i] <- ""
    Output$CWDBFishery[i] <- 46
    Output$SampleType[i] <- 1
    Output$RecordedMark[i] <- 5000
    Output$CatchSampleId[i] <- ""
    Output$DetectionMethod[i] <- "E"
    Output$Agency[i] <- "WDFW"
    # Output$Fishery[i] <- 3045
}


# Export csv files
write.csv(dat, paste(outfile, "R_Output_8.31.20.csv", sep=""))
write.csv(Output, paste(outfile, "WA_FWspt_CAS_load_8.31.20b.csv", sep=""))

